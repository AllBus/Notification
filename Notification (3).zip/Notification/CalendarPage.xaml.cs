﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notification
{
    /// <summary>
    /// Логика взаимодействия для CalendarPage.xaml
    /// </summary>
    public partial class CalendarPage : Page
    {
        public EventData data = EventData.none;

        public CalendarPage()
        {
            InitializeComponent();
        }

        internal void bind(EventData data)
        {
            this.data = data;

            var date = Utils.longToDateTime(data.date);

            dateLabel.Content = date.ToString(Constants.dateLabelFormat);
            timeLabel.Content = date.ToString(Constants.timeLabelFormat);
            durationLabel.Content = Utils.durationToString(data.duration);
            infoText.Text = data.shortInfo;
            kindLabel.Content = data.kind;


            byte[] bytes = BitConverter.GetBytes(data.kindColor);
            kindLabel.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(bytes[3], bytes[2], bytes[1], bytes[0]));
        }
    }
}
