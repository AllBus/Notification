﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Shell;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Windows.UI.Notifications;
using Windows.Data.Xml.Dom;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.Resources;
using System.Windows.Media;

namespace Notification
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        private const String APP_ID = "Главные события";
        List<EventData> eventList = new List<EventData>();

        int eventCount = 0;

        public MainWindow()
        {
            InitializeComponent();


            //TaskbarItemInfo

            ////
            //TabbedThumbnail preview = new TabbedThumbnail(this.Handle, tabPage.Handle);
            ////
            //preview.TabbedThumbnailActivated += new EventHandler<TabbedThumbnailEventArgs>(preview_TabbedThumbnailActivated);
            //preview.TabbedThumbnailClosed += new EventHandler<TabbedThumbnailEventArgs>(preview_TabbedThumbnailClosed);
            //preview.TabbedThumbnailMaximized += new EventHandler<TabbedThumbnailEventArgs>(preview_TabbedThumbnailMaximized);
            //preview.TabbedThumbnailMinimized += new EventHandler<TabbedThumbnailEventArgs>(preview_TabbedThumbnailMinimized);
            ////
            //TaskbarManager.Instance.TabbedThumbnail.AddThumbnailPreview(preview);
            ////
            //tabControl1.SelectedTab = tabPage;
            //TaskbarManager.Instance.TabbedThumbnail.SetActiveTab(tabControl1.SelectedTab);
            ////
        }



        private void sendBtn_Click(object sender, RoutedEventArgs e)
        {


            var data = new EventData();



            data.info = editNotification.Text;
            data.uri = editLink.Text;
            data.shortInfo = data.info;
            data.kind = "Событие";
            data.name = "круто";
            data.image = data.uri;
            data.duration = Utils.dateTimeToLong(new DateTime().AddHours(1).AddMinutes(30));
            data.date = Utils.dateTimeToLong(DateTime.UtcNow.AddMonths(eventCount));
            data.kindColor = System.Drawing.Color.GreenYellow.ToArgb();
            eventCount += 1;

            eventList.Add(data);
            //==================================


            // Get a toast XML template
            XmlDocument toastXml = ToastNotificationManager.GetTemplateContent(ToastTemplateType.ToastImageAndText01);



            // Fill in the text elements
            XmlNodeList stringElements = toastXml.GetElementsByTagName("text");
            for (int i = 0; i < stringElements.Length; i++)
            {
                stringElements[i].AppendChild(toastXml.CreateTextNode(data.info));
            }

            // Specify the absolute path to an image
            String imagePath = "file:///" + Path.GetFullPath("toastImageAndText.png");
            XmlNodeList imageElements = toastXml.GetElementsByTagName("image");
            imageElements[0].Attributes.GetNamedItem("src").NodeValue = imagePath;

            // Create the toast and attach event listeners
            ToastNotification toast = new ToastNotification(toastXml);

            toast.ExpirationTime = new DateTimeOffset(DateTime.Now.AddDays(1));
            toast.Activated += ToastActivated;
            toast.Dismissed += ToastDismissed;
            toast.Failed += ToastFailed;


            // Show the toast. Be sure to specify the AppUserModelId on your application's shortcut!
            // ToastNotificationManager.CreateToastNotifier(APP_ID).Show(toast);

            taskBarItemInfo1.Description = data.info;

            taskBarItemInfo1.ProgressState = TaskbarItemProgressState.Paused;
            taskBarItemInfo1.ProgressValue = 100;

            var contentPage = fullDataFrame.Content as previewEventPage;

            contentPage.bind(data);







            SuperBarNameSpace.NativeMethods.FlashWindow(this, 5);

            updateIcon();



            //  Bitmap myImage = new Bitmap(Notification.Properties.Resources.stopImg);
            //    taskBarItemInfo1.Overlay = (DrawingImage)Notification.Properties.Resources.playImg;
            calendarList.Items.Clear();
            foreach (EventData d in eventList)
            {


                var cv = new CalendarPage();
                cv.Width = 200;
                cv.Height = 250;
                cv.bind(d);

                var fr = new Frame();
                fr.Content = cv;
                var li = new ListBoxItem();

                li.Content = fr;
                calendarList.Items.Add(li);
            }
        }


        public void updateIcon()
        {
            long start = Utils.dateTimeToLong(DateTime.UtcNow.AddHours(-1));
            long end = Utils.dateTimeToLong(DateTime.UtcNow.AddDays(1));
            var ev = eventList.Find(x => x.date >= start && x.date <= end);
            if (ev != null)
            {
                var date = Utils.longToDateTime(ev.date);
                this.Icon = createTimeIcon(date, 0f);

            }
            else
            {
                this.Icon = bitmapToSource(Notification.Properties.Resources.notifiicationPro.ToBitmap());
            }

        }


        private BitmapImage createTimeIcon(DateTime time, float percent)
        {
            Font font = new Font("Arial", 24);
            Font minuteFont = new Font("Arial", 15);
            System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.White);
            System.Drawing.Pen bottomLine = new System.Drawing.Pen(System.Drawing.Color.Green);
            //   pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Right;
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Far;
            sf.LineAlignment = StringAlignment.Center;


            var bit = new Bitmap(96, 96);
            var canvas = Graphics.FromImage(bit);
            //        canvas.Clear(Color.Yellow);

            canvas.DrawString(time.Hour.ToString(), font, pen.Brush, 64, 48, sf);

            sf.Alignment = StringAlignment.Near;
            sf.LineAlignment = StringAlignment.Far;

            canvas.DrawString(time.ToString("mm"), minuteFont, pen.Brush, 60, 48, sf);

            canvas.FillRectangle(bottomLine.Brush, 0 + 96 * percent, 72, 96 * (1f - percent), 24);

            return bitmapToSource(bit);

        }

        public BitmapImage bitmapToSource(Bitmap src)
        {
            MemoryStream ms = new MemoryStream();
            ((System.Drawing.Bitmap)src).Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            ms.Seek(0, SeekOrigin.Begin);
            image.StreamSource = ms;
            image.EndInit();
            return image;
        }

        private void ToastActivated(ToastNotification sender, object e)
        {
            Dispatcher.Invoke(() =>
            {
                taskBarItemInfo1.ProgressState = TaskbarItemProgressState.None;
                Process.Start(editLink.Text);

                // Activate();
                //  Title = "The user activated the toast.";
            });
        }

        private void ToastDismissed(ToastNotification sender, ToastDismissedEventArgs e)
        {
            String outputText = "";
            switch (e.Reason)
            {
                case ToastDismissalReason.ApplicationHidden:
                    outputText = "The app hid the toast using ToastNotifier.Hide";
                    break;
                case ToastDismissalReason.UserCanceled:
                    outputText = "The user dismissed the toast";
                    break;
                case ToastDismissalReason.TimedOut:
                    outputText = "The toast has timed out";
                    break;
            }

            Dispatcher.Invoke(() =>
            {
                //
                Title = outputText;
            });
        }

        private void ToastFailed(ToastNotification sender, ToastFailedEventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                //
                Title = "The toast encountered an error.";
            });
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            taskBarItemInfo1.ProgressState = TaskbarItemProgressState.None;
            SuperBarNameSpace.NativeMethods.StopFlashingWindow(this);
        }

        private void calendarList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = calendarList.SelectedItem;
            if (item is ListBoxItem)
            {
                EventData data = (((item as ListBoxItem).Content as Frame).Content as CalendarPage).data;
                var contentPage = fullDataFrame.Content as previewEventPage;

                contentPage.bind(data);

            }
        }
    }
}
