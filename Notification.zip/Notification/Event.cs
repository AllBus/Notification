﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notification
{
    public class EventData
    {
        public long id = 0;
        public long date = 0;
        public long duration = 0;
        public string name = "";
        public string shortInfo = "";
        public string info = "";
        public string kind = "";
        public string image = "";
        public string uri = "";
        public int kindColor= 0;

        public virtual bool isNull() => false;

        public static EventData none = new NullEventData();
    }


    public class NullEventData : EventData
    {
        override public bool isNull()
        {
            return true;
        }
    }

}

