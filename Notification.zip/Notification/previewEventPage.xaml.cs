﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notification
{
    /// <summary>
    /// Логика взаимодействия для previewEventPage.xaml
    /// </summary>
    public partial class previewEventPage : Page
    {
        public EventData data = EventData.none;

        public previewEventPage()
        {
            InitializeComponent();
        }

        public void gotoItemWebPage()
        {
            if (data.uri.Length > 0)
            {
                Process.Start(data.uri);
            }
        }

        private void linkBtn_Click(object sender, RoutedEventArgs e)
        {
            gotoItemWebPage();
        }

        private void image_TouchUp(object sender, TouchEventArgs e)
        {
            gotoItemWebPage();
        }

        private void image_MouseUp(object sender, MouseButtonEventArgs e)
        {
            gotoItemWebPage();
        }

        internal void bind(EventData data)
        {
            this.data = data;

            var date = Utils.longToDateTime(data.date);

            contentLabel.Text = data.info;
            dateTimeLabel.Content = date.ToString(Constants.longDateFormat);
            kindLabel.Content = data.kind;
            durationLabel.Content = Utils.durationToString(data.duration);

            try
            {
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();

                bitmap.UriSource = new Uri(data.image, UriKind.Absolute);

                bitmap.EndInit();
                image.Source = bitmap;
            }
            catch
            {
                image.Source = null;
            }

        }
    }
}
