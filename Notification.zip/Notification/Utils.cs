﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notification
{
    class Utils
    {
        public static DateTime longToDateTime(long date) => TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(date * 10000));


        public static long dateTimeToLong(DateTime dateTime) => dateTime.Ticks / 10000;

        internal static String durationToString(long duration)
        {
            long sec = duration / 1000;

            var min = sec / 60;
            var hour = min / 60;
            var days = hour / 24;

            hour = hour % 24;
            min = min % 60;
            sec = sec % 60;
            StringBuilder sb = new StringBuilder();
            if (days > 0)
            {
                
                sb.Append(days);
                if (days == 1)
                {
                    sb.Append(" день");
                }
                else
                if (days<5)
                {
                    sb.Append(" дня");
                }
                else
                {
                    sb.Append(" дней");
                }
            }
            else
            {

                if (hour > 0)
                {
                    sb.Append(hour);
                    if (hour == 1)
                    {
                        sb.Append(" час");
                    }
                    else
                      if ((hour - 1) % 10 < 4 && (hour < 10 || hour > 20))
                    {
                        sb.Append(" часа");
                    }
                    else
                    {
                        sb.Append(" часов");
                    }
                    if (min > 0)
                        sb.Append(" ");
                }

                if (min > 0)
                {
                    sb.Append(min);
                    if (min == 1)
                    {
                        sb.Append(" минута");
                    }
                    else
                    if ((min-1)%10 < 4 && (min<10 || min>20))
                    {
                        sb.Append(" минуты");
                    }
                    else
                    {
                        sb.Append(" минут");
                    }
                  
                }
            }
            return sb.ToString();
        }
    }
}
