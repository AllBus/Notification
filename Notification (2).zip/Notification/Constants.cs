﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notification
{
    class Constants
    {
       public const string dateLabelFormat = "d MMMM";
       public const string timeLabelFormat = "HH:mm";
       public const string longDateFormat = "d MMMM в HH:mm";
    }
}
